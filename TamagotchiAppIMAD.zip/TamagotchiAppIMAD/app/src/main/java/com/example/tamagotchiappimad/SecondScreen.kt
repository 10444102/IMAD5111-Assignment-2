package com.example.tamagotchiappimad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView

class SecondScreen : AppCompatActivity() {
    private lateinit var hungerBar: ProgressBar
    private lateinit var happinessBar: ProgressBar
    private lateinit var cleanlinessBar: ProgressBar
    private lateinit var imageView: ImageView
    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)

        // Initialize UI elements
        hungerBar = findViewById(R.id.HungerBar)
        happinessBar = findViewById(R.id.HappinessBar)
        cleanlinessBar = findViewById(R.id.Cleanliness)
        imageView = findViewById(R.id.imageView)
        textView = findViewById(R.id.textView5)

        val feedButton = findViewById<Button>(R.id.buttonFeed)
        val playButton = findViewById<Button>(R.id.buttonPlay)
        val cleanButton = findViewById<Button>(R.id.buttonClean)

        // Set click listeners for buttons
        feedButton.setOnClickListener {
            updateProgress(hungerBar, 10)
            updateProgress(happinessBar, 5) // Increase happiness when feeding.
            changeImageView(R.drawable.eating_pug)
            textView.text = "Feeding time!"
        }

        playButton.setOnClickListener {
            updateProgress(happinessBar, 10)
            changeImageView(R.drawable.pug_play)
            textView.text = "Playtime!"
        }

        cleanButton.setOnClickListener {
            updateProgress(cleanlinessBar, 10)
            updateProgress(happinessBar, -5) // Decrease happiness when cleaning.
            changeImageView(R.drawable.washed_pug)
            textView.text = "Cleaning time!"
        }
    }

    private fun updateProgress(progressBar: ProgressBar, progress: Int) {
        progressBar.progress += progress
        if (progressBar.progress < 0) {
            progressBar.progress = 0
        } else if (progressBar.progress > 100) {
            progressBar.progress = 100
        }
    }

    private fun changeImageView(imageResourceId: Int) {
        imageView.setImageResource(imageResourceId)

        Handler().postDelayed({
            imageView.setImageResource(R.drawable.pug_image)
        }, 3000) // Change back to original photo after 3 seconds.

    }
}